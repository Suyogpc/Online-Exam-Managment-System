from django.contrib import admin

from examapp.models import Quetion

# Register your models here.

admin.site.register(Quetion)
